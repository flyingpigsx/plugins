Video help: https://youtu.be/RK9ZgZqyxWM
My discord: https://discord.gg/bEDGQxc

=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-

Place the "skript.jar" and "skquery.jar" into your plugins folder and restart your server.
After restarting the server, a Skript folder will load. 
Go into "Skript" > "scripts". Once in "scripts" folder, place the "axr.sk" into "scripts" folder.
Go in game and type "/sk reload axr"
Enjoy!